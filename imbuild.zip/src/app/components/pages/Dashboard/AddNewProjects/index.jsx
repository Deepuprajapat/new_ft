import React from 'react'
import '../styles/css/appNewProject.css';
import { AiOutlineCheck } from "react-icons/ai";
import { Steps , Form,Button, message } from 'antd';
import { LogoutOutlined, ProfileOutlined } from '@ant-design/icons';
import { MedicalServicesOutlined } from '@mui/icons-material';
import { MdOutlinePermMedia } from "react-icons/md";
import { BsFillBuildingsFill } from "react-icons/bs";
const index = () => {
  return (
    <div className='App'>
   

  </div>
  )
}

export default index
