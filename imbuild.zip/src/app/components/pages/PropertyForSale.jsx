// import React from 'react'

// const PropertyDetails = () => {
//   return (
//     <div>
    
//     </div>
//   )
// }

// export default PropertyDetails
